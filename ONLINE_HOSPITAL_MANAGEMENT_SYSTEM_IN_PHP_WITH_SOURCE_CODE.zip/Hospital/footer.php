<div class="wrapper col5">
  <div id="footer">

    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved | <a href="adminlogin.php">Admin Login Panel</a> | <a href="doctorlogin.php">Doctor Login Panel</a></p>
      <p class="fl_right">Developed by <a href="https://www.studentprojectguide.com">www.studentprojectguide.com</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>